require File.dirname(__FILE__) + "/test_helper"
require "go_to_external"

class TestGoToExternal < Test::Unit::TestCase
  def test_case_name
    
  end
end