// Relative Paths
// @require 'relative_path.js';
// @require 'relative_path.css';

// Urls
// @require 'http://ajax.googleapis.com/ajax/libs/mootools/1.2.1/mootools.js';

// Libraries
// @require 'mootools';
// @require 'jsspec';

window.alert('alerts')

window.confirm('confirms') 
	? window.alert('confirmed') 
	: window.alert('not confirmed')
;

try{throw {}}catch(e){ console.log(e.line); }; FRED++






