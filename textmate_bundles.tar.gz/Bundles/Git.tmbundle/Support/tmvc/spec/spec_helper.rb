SPEC_ROOT = File.dirname(__FILE__)

require SPEC_ROOT + "/../tmvc.rb"
require SPEC_ROOT + "/spec_helpers.rb"