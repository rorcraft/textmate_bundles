Jade.tmbundle
---------------------

A **TextMate Bundle** for the **Jade** templating language.

Installation:

    mkdir -p ~/Library/Application\ Support/TextMate/Bundles
    cd ~/Library/Application\ Support/TextMate/Bundles
    git clone git://github.com/miksago/jade-tmbundle Jade.tmbundle

The bundle currently only includes syntax highlighting.

Patches for additions are always welcome.