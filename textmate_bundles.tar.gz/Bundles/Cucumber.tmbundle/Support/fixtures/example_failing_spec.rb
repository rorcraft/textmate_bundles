describe "An example failing spec" do
  it "should fail" do
    true.should be_false
  end

  it "should also fail" do
    false.should be_true
  end
end
