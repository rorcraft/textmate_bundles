require File.dirname(__FILE__) + '/../../spec_helper'
require File.dirname(__FILE__) + '/../../../lib/cucumber/mate/text_mate_helper'

module Cucumber
  module Mate
  
    describe TextMateHelper do
    end

  end
end